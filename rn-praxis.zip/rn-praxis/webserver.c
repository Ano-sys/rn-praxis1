#define WIN32_LEAN_AND_MEAN

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <windows.h>
#include <winsock2.h>

int main(int argc, char** argv){
    char* socket = argv[1];
    int port = atoi(argv[2]);

    printf("Socket: %s\n", socket);
    printf("Port: %d", port);

    getaddrinfo();
    return 0;
}